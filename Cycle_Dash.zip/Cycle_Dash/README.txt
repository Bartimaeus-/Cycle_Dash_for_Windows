CYCLE DASH FOR WINDOWS BY BARTIMAEUS
12/7/2012

This program was written for the Cycle Analyst to display and store data.

USE IS AT YOUR OWN RISK. I TAKE NO RESPONSIBILITY FOR ANY DAMAGES CAUSED BY THIS SOFTWARE IN ANY WAY.

IF YOU HAVE ANY QUESTIONS, PLEASE FEEL FREE TO SEND A PM TO Bartimaeus ON THE ENDLESS-SPHERE FORUM: www.endless-sphere.com

Credits: This program was made using the QAsyncSerial library written by Terraneo Federico, the Qt plug-in for Microsoft Visual Studio 2010 and the Qt libraries, and the Boost libraries.

/////////////////////////////////////////////////////////
///////////////INSTALLATION INSTRUCTIONS////////////////
/////////////////////////////////////////////////////////

1. Download the "Cycle_Dash.zip" file to your computer.

2. Extract to whatever directory you want.

3. To use the program click on Cycle_Dash.exe

4. You must leave the .exe file in the same directory as the QtCore4.dll and QtGui4.dll files.
   However you can create a shortcut and place it wherever you like and launch the application from there.